import uuid

#用10位学号替换12位MAC地址，再与时间戳一起生成uuid version1
def generate_uuid(sno,current_timestamp):
    timestamp = int((current_timestamp + 12219292800) * 10**7)
    student_number_int = int(sno)
    uuid_version_1 = uuid.uuid1(node=student_number_int, clock_seq=timestamp)
    return(uuid_version_1)











