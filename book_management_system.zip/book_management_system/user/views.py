from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import login,authenticate
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.utils import timezone
from datetime import timedelta
from django.contrib import messages
from .models import student,book,borrow_and_return,BarConfirm
from .forms import signupform,loginform,bookform,borrowform
from .get_uuid import generate_uuid

# Create your views here.
def signup_for_user(request):
    '''注册界面'''
    if request.method == 'POST':
        form = signupform(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "账户创建成功！")
            return redirect('/accounts/index/')
        else:
            messages.error(request, "请正确输入。")
    else:
        form = signupform()
    return render(request, 'signup.html', {'form': form})

def login_for_user(request):
    '''登录界面''' 
    if request.method == 'POST':
        form = loginform(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, "登录成功！")
                return redirect('/accounts/index/') 
            else:
                messages.error(request, "无效的用户名或密码。")
        else:
            messages.error(request, "表单无效。")
    else:
        form = loginform()
    return render(request, 'login.html', {'form': form})

def index_for_user(request):
    '''主界面'''
    return render(request, "index.html")

@login_required(login_url='/accounts/login/')
def book_for_user(request):
    '''图书界面'''
#搜索
    search_data = request.GET.get("search")
    if search_data:
        books = book.objects.filter(bno__icontains=search_data).order_by('id')
    else:
        books = book.objects.all().order_by('id')

    #分页
    page_str = request.GET.get("page")
    if page_str:
        page = int(page_str)
    else:
        page =1
    page_max_item = 10

    #页码应用
    paginator = Paginator(books, page_max_item)
    try:
        page_obj = paginator.get_page(page)
    except Exception:
        page_obj = paginator.get_page(1) 

    return render(request, "book.html", {
        "book_queryset": page_obj.object_list,  
        "search_data": search_data,         
        "page_num": paginator.page_range,    
        "current_page": page,                
        "total_pages": paginator.num_pages,   
        "total": paginator.count,         
    })

@login_required(login_url='/accounts/login/')
def bar_for_user(request):
    '''借阅界面'''
    user = request.user
    student_sno = user.username
    #搜索
    search_data = request.GET.get("search")
    if search_data:
        records = borrow_and_return.objects.filter(sno=student_sno, bno__icontains=search_data).order_by('id')
    else:
        records = borrow_and_return.objects.filter(sno=student_sno).order_by('id')

    #分页
    page_str = request.GET.get("page")
    if page_str:
        page = int(page_str)
    else:
        page =1
    page_max_item = 10

    #页码应用
    paginator = Paginator(records, page_max_item)
    try:
        page_obj = paginator.get_page(page)
    except Exception:
        page_obj = paginator.get_page(1) 

    return render(request, "borrow.html", {
        "borrow_queryset": page_obj.object_list,  
        "search_data": search_data,         
        "page_num": paginator.page_range,    
        "current_page": page,                
        "total_pages": paginator.num_pages,   
        "total": paginator.count,         
    })

def borrow_for_user(request): 
    '''借阅请求'''
    user = request.user
    sno = user.username   
    bno = request.POST.get('bno')
    isbn = request.POST.get('isbn')
    try:
        sno_instance = student.objects.get(sno=sno)
    except student.DoesNotExist:
        messages.error(request, '该学生不存在')
        return redirect('book')
    name_instance = sno_instance.name
    
    borrow_date = timezone.now()
    current_timestamp = borrow_date.timestamp()
    uuid = generate_uuid(sno, current_timestamp)  

    record = BarConfirm.objects.create(
        uuid=uuid,
        sno=sno_instance,
        name=name_instance,
        bno=bno,
        isbn=isbn,
        borrow_date=borrow_date,
        state="borrow",
        status="padding"
    )
    messages.success(request, "借阅申请已进入审批队列！")
    return redirect('book')

def renew_for_user(request,record_id):
    '''续借请求'''
    if request.method == "POST":
        borrow_record = get_object_or_404(borrow_and_return, id=record_id)
        current_timestamp = timezone.now().timestamp()
        uuid = generate_uuid(borrow_record.sno.sno, current_timestamp) #sno是外键，要两次
        record = BarConfirm.objects.create(
        uuid=uuid,
        uuid_post=borrow_record.uuid,
        sno=borrow_record.sno.sno,
        name=borrow_record.name,
        bno=borrow_record.bno,
        isbn=borrow_record.isbn.isbn,
        borrow_date=borrow_record.borrow_date,
        return_deadline=borrow_record.return_deadline,
        state="renew",
        status="padding"
        )
        messages.success(request, "续借申请已进入审批队列！")
        return redirect('bar')  

def return_for_user(request,record_id):
    '''归还请求'''
    if request.method == "POST":
        borrow_record = get_object_or_404(borrow_and_return, id=record_id)
        current_timestamp = timezone.now().timestamp()
        uuid = generate_uuid(borrow_record.sno.sno, current_timestamp)#sno是外键，要两次
        record = BarConfirm.objects.create(
        uuid=uuid,
        uuid_post=borrow_record.uuid,
        sno=borrow_record.sno.sno,
        name=borrow_record.name,
        bno=borrow_record.bno,
        isbn=borrow_record.isbn.isbn,
        borrow_date=borrow_record.borrow_date,
        return_deadline=borrow_record.return_deadline,
        state="return",
        status="padding"
        )
        messages.success(request, "归还申请已进入审批队列！")
        return redirect('bar')  

@login_required(login_url='/admin/login/')
def confirm_for_user(request):
    '''审批界面'''
    user = request.user
    if user.is_superuser:
        search_data = request.GET.get("search")
        records = BarConfirm.objects.all().order_by('-id')
        #分页
        page_str = request.GET.get("page")
        if page_str:
            page = int(page_str)
        else:
            page =1
        page_max_item = 10

        #页码应用
        paginator = Paginator(records, page_max_item)
        try:
            page_obj = paginator.get_page(page)
        except Exception:
            page_obj = paginator.get_page(1) 

        return render(request, "confirm.html", {
            "borrow_queryset": page_obj.object_list,
            "search_data": search_data,      
            "page_num": paginator.page_range,    
            "current_page": page,                
            "total_pages": paginator.num_pages,   
            "total": paginator.count,         
        })
    else:
        return redirect('/admin/login/')

def confirm_by_admin(request,quest_id):
    '''借阅、续借、归还审批'''
    if request.method == "POST":
        instance=get_object_or_404(BarConfirm,id=quest_id)
        if instance.state=="borrow":
            sno=instance.sno
            try:
                sno_instance = student.objects.get(sno=sno)
            except student.DoesNotExist:
                messages.error(request, '该学生不存在')
                return redirect('book')
            name_instance = sno_instance.name
            isbn=instance.isbn
            try:
                isbn_instance = book.objects.get(isbn=isbn)
            except book.DoesNotExist:
                messages.error(request, '该书籍不存在')
                return redirect('book')
            bno_instance=isbn_instance.bno
                
            borrow_date = timezone.now()
            current_timestamp = borrow_date.timestamp()
            uuid = generate_uuid(sno, current_timestamp)
                
            borrow_record = borrow_and_return.objects.create(
                uuid=uuid,
                sno=sno_instance,
                name=name_instance,
                bno=bno_instance,
                isbn=isbn_instance,
                borrow_date=borrow_date,
                return_deadline=borrow_date + timedelta(days=10),
                return_date=None
                )
            book_instance = get_object_or_404(book, isbn=isbn_instance)
            book_instance.number_in_storage -= 1 
            book_instance.save()
            instance.status="approved"
            instance.uuid_post=uuid
            instance.save()
            
        elif instance.state=="renew":
            renew_record=get_object_or_404(borrow_and_return,uuid=instance.uuid_post)
            renew_record.return_deadline+=timedelta(days=10)
            renew_record.save()
            instance.status="approved"
            instance.save()
            
        elif instance.state=="return":
            return_record=get_object_or_404(borrow_and_return,uuid=instance.uuid_post)
            return_record.return_date=timezone.now()
            return_record.save()
            book_instance = get_object_or_404(book, isbn=instance.isbn)
            book_instance.number_in_storage += 1 
            book_instance.save()
            instance.status="approved"
            instance.save()
            
        return redirect('confirm')