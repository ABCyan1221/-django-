from django.contrib import admin
from .models import student,book,borrow_and_return,BarConfirm
# Register your models here.

admin.site.register(student)
admin.site.register(book)
admin.site.register(borrow_and_return)
admin.site.register(BarConfirm)
