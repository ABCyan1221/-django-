from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth.models import User
from .models import student,book,borrow_and_return

class signupform(UserCreationForm):
    class Meta:
        model = User
        fields = [
            'username',
            'password1',
            'password2'
        ]
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not username:
            raise forms.ValidationError("Username cannot be empty.")
        if not student.objects.filter(sno=username).exists():
            raise forms.ValidationError("This username must correspond to a student number (sno) in the system.")
        return username

class loginform(AuthenticationForm):
    class Meta:
        model = User
        fields = [
            'username',
            'password'
        ]
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not username:
            raise forms.ValidationError("Username cannot be empty.")
        if not student.objects.filter(sno=username).exists():
            raise forms.ValidationError("This username must correspond to a student number (sno) in the system.")
        return username

        
class studentform(forms.ModelForm):
    class Meta:
        model = student
        fields = [
            'sno',
            'name',
            'cno',
            'department',
            'major',
            'phone_mail',
            'graduation_year'
            ]
    sno = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter student number'}))
    name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter name'}))
    cno = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter class number'}))
    department = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter department'}))
    major = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter major'}))
    phone_mail = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter phone-number or mail-address'}))
    graduation_year = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control','placeholder': 'Enter graduation year'}))

class bookform(forms.ModelForm):
    class Meta:
        model = book
        fields = [
            'bno', 
            'author',
            'isbn',
            'publisher',
            'number_in_all',
            'number_in_storage'
            ]
    bno = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter book name'}))
    author = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter auther'}))
    isbn = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter ISBN'}))
    publisher = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control','placeholder': 'Enter publisher'}))
    number_in_all = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control','placeholder': 'Enter number of books in all'}))
    number_in_storage = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control','placeholder': 'Enter number of books in stock'}))    

class borrowform(forms.ModelForm):
    class Meta:
        model = borrow_and_return
        fields = [
            'bno',
            'isbn',
            ]
    bno = forms.CharField(widget=forms.HiddenInput())
    isbn = forms.CharField(widget=forms.HiddenInput())



