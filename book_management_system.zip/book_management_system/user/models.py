from django.db import models
from datetime import timedelta
from django.contrib.auth.models import User 

# Create your models here.
class student(models.Model):
    '''学生信息表'''
    sno=models.CharField(verbose_name="学号",max_length=10,unique=True)
    name=models.CharField(verbose_name="姓名",max_length=20)
    cno=models.CharField(verbose_name="班级",max_length=10)
    department=models.CharField(verbose_name="学院",max_length=20)
    major=models.CharField(verbose_name="专业",max_length=20)
    phone_mail=models.CharField(verbose_name="联系方式",max_length=30)
    graduation_year=models.IntegerField(verbose_name="毕业年份")
    def __str__(self):
        return self.sno

class book(models.Model):
    '''书籍信息表'''
    bno=models.CharField(verbose_name="书名",max_length=40)
    author=models.CharField(verbose_name="作者",max_length=100)
    isbn=models.CharField(verbose_name="ISBN",max_length=14,unique=True)
    publisher=models.CharField(verbose_name="出版社",max_length=40)
    #持有数量=在库数量+借出数量
    number_in_all=models.IntegerField(verbose_name="持有数量")
    number_in_storage=models.IntegerField(verbose_name="在库数量")
    def __str__(self):
        return self.isbn

class borrow_and_return(models.Model):
    '''借阅信息表'''
    uuid=models.UUIDField(verbose_name="UUID",unique=True)
    sno=models.ForeignKey(verbose_name="学号",to="student", to_field="sno",on_delete=models.CASCADE)
    name=models.CharField(verbose_name="姓名",max_length=20)
    bno=models.CharField(verbose_name="书名",max_length=40)
    isbn=models.ForeignKey(verbose_name="ISBN",to="book", to_field="isbn",on_delete=models.CASCADE)
    borrow_date=models.DateTimeField(verbose_name="借出日期")
    #归还期限=借出日期+10days
    return_deadline = models.DateTimeField(verbose_name="归还期限",null=True, blank=True)
    return_date=models.DateTimeField(verbose_name="归还日期",null=True, blank=True)
        
class BarConfirm(models.Model):
    '''请求信息表'''
    
    STATUS_CHOICES = [
        ("pending", "待审批"),
        ("approved", "已批准"),
        ("rejected", "已拒绝"),
    ]
    STATE_CHOICES = [
        ("borrow", "借阅"),
        ("renew", "续借"),
        ("return", "归还"),
    ]
    uuid = models.UUIDField(verbose_name="UUID", unique=True)
    uuid_post = models.UUIDField(verbose_name="传递UUID",null=True, blank=True)
    sno=models.CharField(verbose_name="学号",max_length=10)
    name = models.CharField(verbose_name="姓名", max_length=20)
    bno = models.CharField(verbose_name="书名", max_length=40)
    isbn=models.CharField(verbose_name="ISBN",max_length=14)
    borrow_date = models.DateTimeField(verbose_name="借出日期")
    return_deadline = models.DateTimeField(verbose_name="归还期限", null=True, blank=True)
    return_date = models.DateTimeField(verbose_name="归还日期", null=True, blank=True)
    state = models.CharField(verbose_name="请求状态", max_length=10, choices=STATE_CHOICES)
    status = models.CharField(verbose_name="审批状态", max_length=10, choices=STATUS_CHOICES)